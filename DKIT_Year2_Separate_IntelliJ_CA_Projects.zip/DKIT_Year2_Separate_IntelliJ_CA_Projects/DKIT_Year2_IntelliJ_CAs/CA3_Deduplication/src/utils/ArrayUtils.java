package utils;

/**
 * Methods for removing duplicate integer values from arrays.
 */
public class ArrayUtils {

    /**
     * Removes duplicates by growing the result one position for each new value.
     * The first occurrence order is preserved.
     * @param nums the original values
     * @return a new array containing each distinct value once
     */
    public static int[] deduplicate(int[] nums) {
        int[] result = new int[0];
        for (int num : nums) {
            boolean found = false;
            for (int value : result) {
                if (value == num) {
                    found = true;
                    break;
                }
            }
            if (!found) {
                int[] larger = new int[result.length + 1];
                for (int i = 0; i < result.length; i++) larger[i] = result[i];
                larger[larger.length - 1] = num;
                result = larger;
            }
        }
        return result;
    }

    /**
     * Removes duplicate grades using -1 as a temporary blank marker.
     * Valid grades are 0 to 100. The supplied array is not changed.
     * @param grades the original grade array
     * @return a correctly sized array containing each grade once
     */
    public static int[] filterDuplicates(int[] grades) {
        int[] working = new int[grades.length];
        for (int i = 0; i < grades.length; i++) working[i] = grades[i];

        for (int i = 0; i < working.length; i++) {
            if (working[i] != -1) {
                for (int j = i + 1; j < working.length; j++) {
                    if (working[i] == working[j]) working[j] = -1;
                }
            }
        }

        int count = 0;
        for (int value : working) if (value != -1) count++;

        int[] result = new int[count];
        int index = 0;
        for (int value : working) {
            if (value != -1) {
                result[index] = value;
                index++;
            }
        }
        return result;
    }

    /**
     * Removes duplicates from an ascending sorted array by comparing neighbours.
     * @param nums an integer array sorted in ascending order
     * @return a correctly sized array containing each distinct value once
     */
    public static int[] sortedDeduplicate(int[] nums) {
        if (nums.length == 0) return new int[0];

        int count = 1;
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] != nums[i - 1]) count++;
        }

        int[] result = new int[count];
        result[0] = nums[0];
        int index = 1;
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] != nums[i - 1]) {
                result[index] = nums[i];
                index++;
            }
        }
        return result;
    }
}
