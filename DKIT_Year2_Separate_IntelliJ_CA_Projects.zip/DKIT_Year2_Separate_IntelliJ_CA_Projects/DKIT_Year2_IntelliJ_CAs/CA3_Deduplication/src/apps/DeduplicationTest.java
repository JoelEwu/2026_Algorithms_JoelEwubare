package apps;

import utils.ArrayUtils;
import java.util.Arrays;
import java.util.Scanner;

/** Tests all three duplicate-removal approaches with user-entered grades. */
public class DeduplicationTest {
    private static void display(String label, int[] values) {
        System.out.println(label + ": " + Arrays.toString(values));
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] grades = new int[10];

        System.out.println("=== CA3: Deduplication ===");
        for (int i = 0; i < grades.length; i++) {
            int grade;
            do {
                System.out.print("Enter grade " + (i + 1) + " (0-100): ");
                while (!input.hasNextInt()) {
                    System.out.print("Enter a whole number: ");
                    input.next();
                }
                grade = input.nextInt();
            } while (grade < 0 || grade > 100);
            grades[i] = grade;
        }

        display("\\nOriginal grades", grades);

        int[] growthResult = ArrayUtils.deduplicate(grades);
        int[] blankResult = ArrayUtils.filterDuplicates(grades);

        int[] sortedCopy = Arrays.copyOf(grades, grades.length);
        Arrays.sort(sortedCopy);
        int[] sortedResult = ArrayUtils.sortedDeduplicate(sortedCopy);

        display("Array growth result", growthResult);
        display("Blank deletion result", blankResult);
        display("Sorted-array result", sortedResult);
        System.out.println("Duplicates removed (array growth): " + (grades.length - growthResult.length));
        System.out.println("Duplicates removed (blank deletion): " + (grades.length - blankResult.length));
        System.out.println("Duplicates removed (sorted method): " + (grades.length - sortedResult.length));

        System.out.println("\\n=== Additional test cases ===");
        int[][] tests = {
                {4, 4, 2, 2, 9},
                {1, 2, 3, 4},
                {7},
                {}
        };
        for (int i = 0; i < tests.length; i++) {
            display("Test " + (i + 1) + " input", tests[i]);
            display("Test " + (i + 1) + " output", ArrayUtils.deduplicate(tests[i]));
        }
    }
}
