package apps;

import utils.ArrayUtils;
import java.util.Scanner;

/** Demonstrates partitioning ten grades around a pass-mark pivot. */
public class NumberPartitioning {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] grades = new int[10];
        final int PASS_MARK = 40;

        System.out.println("Enter ten grades (0-100):");
        for (int i = 0; i < grades.length; i++) {
            int grade;
            do {
                System.out.print("Grade " + (i + 1) + ": ");
                while (!input.hasNextInt()) {
                    System.out.print("Enter a whole number: ");
                    input.next();
                }
                grade = input.nextInt();
            } while (grade < 0 || grade > 100);
            grades[i] = grade;
        }

        int[] result = ArrayUtils.partition(grades, PASS_MARK);
        System.out.println("\\nPartitioned grades (greater than 40 first):");
        for (int i = 0; i < result.length; i++) {
            System.out.println("Position " + i + ": " + result[i]);
        }

        // The first value at or below the pivot marks the start of the non-pass section.
        int passCount = 0;
        while (passCount < result.length && result[passCount] > PASS_MARK) passCount++;
        System.out.println("Number of grades above the pass mark: " + passCount);
    }
}
