package apps;

import utils.ArrayUtils;
import java.util.Arrays;
import java.util.Scanner;

/** Demonstrates unsorted and sorted merging of two integer arrays. */
public class NumberMerging {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] first = new int[5];
        int[] second = new int[5];

        System.out.println("Enter five numbers for array 1:");
        for (int i = 0; i < first.length; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            while (!input.hasNextInt()) {
                System.out.print("Enter a whole number: ");
                input.next();
            }
            first[i] = input.nextInt();
        }

        System.out.println("Enter five numbers for array 2:");
        for (int i = 0; i < second.length; i++) {
            System.out.print("Number " + (i + 1) + ": ");
            while (!input.hasNextInt()) {
                System.out.print("Enter a whole number: ");
                input.next();
            }
            second[i] = input.nextInt();
        }

        int[] merged = ArrayUtils.merge(first, second);
        System.out.println("\\nUnsorted merge: " + Arrays.toString(merged));

        Arrays.sort(first);
        Arrays.sort(second);
        int[] ordered = ArrayUtils.orderedMerge(first, second);
        System.out.println("Ordered merge: " + Arrays.toString(ordered));
    }
}
