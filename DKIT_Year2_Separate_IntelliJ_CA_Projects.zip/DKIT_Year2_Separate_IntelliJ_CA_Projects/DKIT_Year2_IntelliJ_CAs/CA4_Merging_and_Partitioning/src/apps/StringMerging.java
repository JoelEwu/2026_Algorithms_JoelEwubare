package apps;

import utils.ArrayUtils;
import java.util.Arrays;
import java.util.Scanner;

/** Demonstrates merging two groups of words alphabetically. */
public class StringMerging {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] first = new String[5];
        String[] second = new String[5];

        System.out.println("Enter five words for array 1:");
        for (int i = 0; i < first.length; i++) {
            System.out.print("Word " + (i + 1) + ": ");
            first[i] = input.nextLine();
        }

        System.out.println("Enter five words for array 2:");
        for (int i = 0; i < second.length; i++) {
            System.out.print("Word " + (i + 1) + ": ");
            second[i] = input.nextLine();
        }

        Arrays.sort(first, String.CASE_INSENSITIVE_ORDER);
        Arrays.sort(second, String.CASE_INSENSITIVE_ORDER);
        String[] merged = ArrayUtils.orderedMerge(first, second);
        System.out.println("\\nMerged words in alphabetical order:");
        for (int i = 0; i < merged.length; i++) {
            System.out.println((i + 1) + ". " + merged[i]);
        }
    }
}
