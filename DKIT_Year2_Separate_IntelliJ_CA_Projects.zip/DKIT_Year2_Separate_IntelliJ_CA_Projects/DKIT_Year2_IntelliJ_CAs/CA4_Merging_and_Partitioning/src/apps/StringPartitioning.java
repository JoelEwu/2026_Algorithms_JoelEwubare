package apps;

import utils.ArrayUtils;
import java.util.Scanner;

/** Demonstrates partitioning ten names around a chosen pivot name. */
public class StringPartitioning {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] names = new String[10];

        System.out.println("Enter ten names:");
        for (int i = 0; i < names.length; i++) {
            System.out.print("Name " + (i + 1) + ": ");
            names[i] = input.nextLine();
        }

        System.out.print("Enter a pivot name: ");
        String pivot = input.nextLine();

        String[] result = ArrayUtils.partition(names, pivot);
        System.out.println("\\nNames in partitioned alphabetical order:");
        for (int i = 0; i < result.length; i++) {
            System.out.println((i + 1) + ". " + result[i]);
        }
    }
}
