package utils;

import java.util.Arrays;

/**
 * Methods for merging and partitioning integer and String arrays.
 */
public class ArrayUtils {

    /**
     * Joins two integer arrays, preserving their original order.
     * @param nums1 first array
     * @param nums2 second array
     * @return a new array containing both arrays
     */
    public static int[] merge(int[] nums1, int[] nums2) {
        int[] merged = new int[nums1.length + nums2.length];
        for (int i = 0; i < nums1.length; i++) merged[i] = nums1[i];
        for (int i = 0; i < nums2.length; i++) merged[nums1.length + i] = nums2[i];
        return merged;
    }

    /**
     * Merges two ascending integer arrays into ascending order.
     * @param nums1 first sorted array
     * @param nums2 second sorted array
     * @return the merged sorted array
     */
    public static int[] orderedMerge(int[] nums1, int[] nums2) {
        int[] merged = new int[nums1.length + nums2.length];
        int i = 0, j = 0, k = 0;
        while (i < nums1.length && j < nums2.length) {
            if (nums1[i] <= nums2[j]) merged[k++] = nums1[i++];
            else merged[k++] = nums2[j++];
        }
        while (i < nums1.length) merged[k++] = nums1[i++];
        while (j < nums2.length) merged[k++] = nums2[j++];
        return merged;
    }

    /**
     * Merges two alphabetically sorted String arrays, ignoring case.
     * @param text1 first sorted String array
     * @param text2 second sorted String array
     * @return the merged alphabetically sorted array
     */
    public static String[] orderedMerge(String[] text1, String[] text2) {
        String[] merged = new String[text1.length + text2.length];
        int i = 0, j = 0, k = 0;
        while (i < text1.length && j < text2.length) {
            if (text1[i].compareToIgnoreCase(text2[j]) <= 0) merged[k++] = text1[i++];
            else merged[k++] = text2[j++];
        }
        while (i < text1.length) merged[k++] = text1[i++];
        while (j < text2.length) merged[k++] = text2[j++];
        return merged;
    }

    /**
     * Places values greater than pivot first, followed by values at or below pivot.
     * This partitions the values but does not fully sort them.
     * @param nums values to partition
     * @param pivot comparison value
     * @return partitioned array, with values greater than pivot first
     */
    public static int[] partition(int[] nums, int pivot) {
        int[] greater = new int[nums.length];
        int[] lowerOrEqual = new int[nums.length];
        int greaterCount = 0, lowerCount = 0;

        for (int num : nums) {
            if (num > pivot) greater[greaterCount++] = num;
            else lowerOrEqual[lowerCount++] = num;
        }

        int[] first = new int[greaterCount];
        int[] second = new int[lowerCount];
        for (int i = 0; i < greaterCount; i++) first[i] = greater[i];
        for (int i = 0; i < lowerCount; i++) second[i] = lowerOrEqual[i];
        return merge(first, second);
    }

    /**
     * Partitions Strings around a pivot and returns the result alphabetically.
     * @param text Strings to partition
     * @param pivot comparison String
     * @return all Strings in ascending alphabetical order
     */
    public static String[] partition(String[] text, String pivot) {
        String[] beforeOrEqual = new String[text.length];
        String[] after = new String[text.length];
        int firstCount = 0, secondCount = 0;

        for (String word : text) {
            if (word.compareToIgnoreCase(pivot) <= 0) beforeOrEqual[firstCount++] = word;
            else after[secondCount++] = word;
        }

        String[] first = Arrays.copyOf(beforeOrEqual, firstCount);
        String[] second = Arrays.copyOf(after, secondCount);
        Arrays.sort(first, String.CASE_INSENSITIVE_ORDER);
        Arrays.sort(second, String.CASE_INSENSITIVE_ORDER);
        return orderedMerge(first, second);
    }
}
