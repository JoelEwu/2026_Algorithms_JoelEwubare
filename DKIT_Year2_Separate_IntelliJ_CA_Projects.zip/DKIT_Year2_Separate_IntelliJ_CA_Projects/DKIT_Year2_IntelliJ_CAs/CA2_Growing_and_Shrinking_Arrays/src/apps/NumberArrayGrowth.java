package apps;

import utils.ArrayUtils;
import java.util.Scanner;

/** Demonstrates growing an integer array when it becomes full. */
public class NumberArrayGrowth {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int size;
        do {
            System.out.print("Choose the starting array size: ");
            while (!input.hasNextInt()) {
                System.out.print("Enter a whole number: ");
                input.next();
            }
            size = input.nextInt();
        } while (size <= 0);

        int[] numbers = new int[size];
        int count = 0;
        boolean more = true;

        while (more) {
            while (count < numbers.length) {
                System.out.print("Enter number " + (count + 1) + ": ");
                while (!input.hasNextInt()) {
                    System.out.print("Enter a whole number: ");
                    input.next();
                }
                numbers[count] = input.nextInt();
                count++;
            }

            System.out.print("Array is full. Add more numbers? (yes/no): ");
            String answer = input.next();
            if (answer.equalsIgnoreCase("yes")) {
                numbers = ArrayUtils.grow(numbers);
                System.out.println("Array grown to " + numbers.length + " positions.");
            } else {
                more = false;
            }
        }

        System.out.println("\\nNumbers entered:");
        for (int i = 0; i < count; i++) {
            System.out.println("Position " + i + ": " + numbers[i]);
        }
    }
}
