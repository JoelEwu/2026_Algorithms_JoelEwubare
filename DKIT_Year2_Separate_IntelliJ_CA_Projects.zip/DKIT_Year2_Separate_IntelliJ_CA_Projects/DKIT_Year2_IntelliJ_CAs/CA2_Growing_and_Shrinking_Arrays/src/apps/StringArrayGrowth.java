package apps;

import utils.ArrayUtils;
import java.util.Scanner;

/** Demonstrates adding words to a String array and shrinking it afterwards. */
public class StringArrayGrowth {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String[] words = new String[5];
        int count = 0;
        String answer;

        do {
            System.out.print("Would you like to enter a word? (yes/no): ");
            answer = input.nextLine();

            if (answer.equalsIgnoreCase("yes")) {
                if (count == words.length) {
                    words = ArrayUtils.resize(words, words.length + 5);
                    System.out.println("Array expanded to " + words.length + " positions.");
                }
                System.out.print("Enter word: ");
                words[count] = input.nextLine();
                count++;
            }
        } while (answer.equalsIgnoreCase("yes"));

        // Remove unused positions before displaying the words entered.
        words = ArrayUtils.resize(words, count);
        System.out.println("\\nWords entered:");
        for (int i = 0; i < words.length; i++) {
            System.out.println("Position " + i + ": " + words[i]);
        }

        int keep;
        do {
            System.out.print("How many words would you like to keep (0-" + count + ")? ");
            while (!input.hasNextInt()) {
                System.out.print("Enter a whole number: ");
                input.next();
            }
            keep = input.nextInt();
        } while (keep < 0 || keep > count);

        String[] keptWords = ArrayUtils.resize(words, keep);
        System.out.println("\\nFinal shortened array:");
        for (int i = 0; i < keptWords.length; i++) {
            System.out.println("Position " + i + ": " + keptWords[i]);
        }
    }
}
