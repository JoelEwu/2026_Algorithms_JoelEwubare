package utils;

/**
 * Methods for growing and resizing arrays.
 */
public class ArrayUtils {

    /**
     * Returns a new integer array with ten extra positions.
     * @param nums the original integer array
     * @return a new array containing all original values and ten extra slots
     */
    public static int[] grow(int[] nums) {
        int[] larger = new int[nums.length + 10];
        for (int i = 0; i < nums.length; i++) larger[i] = nums[i];
        return larger;
    }

    /**
     * Copies text into a new array of the requested size.
     * @param text the original String array
     * @param newSize the required size of the new array
     * @return the resized array; values are truncated if newSize is smaller
     */
    public static String[] resize(String[] text, int newSize) {
        if (newSize < 0) throw new IllegalArgumentException("Array size cannot be negative.");
        String[] resized = new String[newSize];
        int limit = Math.min(text.length, newSize);
        for (int i = 0; i < limit; i++) resized[i] = text[i];
        return resized;
    }
}
