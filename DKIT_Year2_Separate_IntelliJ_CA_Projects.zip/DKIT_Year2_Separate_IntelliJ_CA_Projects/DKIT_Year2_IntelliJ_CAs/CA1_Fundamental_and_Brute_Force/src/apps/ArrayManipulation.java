package apps;

import utils.ArrayUtils;
import java.util.Scanner;

/**
 * Demonstrates the fundamental and brute-force array exercises.
 */
public class ArrayManipulation {
    private static final Scanner input = new Scanner(System.in);

    private static int readGrade(int position) {
        int grade;
        do {
            System.out.print("Enter grade " + position + " (0-100): ");
            while (!input.hasNextInt()) {
                System.out.print("Please enter a whole number: ");
                input.next();
            }
            grade = input.nextInt();
        } while (grade < 0 || grade > 100);
        return grade;
    }

    public static void main(String[] args) {
        int[] grades = new int[10];

        System.out.println("=== CA1: Array Manipulation ===");
        for (int i = 0; i < grades.length; i++) grades[i] = readGrade(i + 1);

        System.out.println("\\nGrades entered:");
        ArrayUtils.displayArray(grades);
        System.out.printf("Average/GPA: %.2f%n", ArrayUtils.calcAverage(grades));
        System.out.println("Highest grade: " + ArrayUtils.findMax(grades));
        System.out.println("Lowest grade: " + ArrayUtils.findMin(grades));
        System.out.println("Number of grades equal to 70: " + ArrayUtils.count(grades, 70));
        System.out.println("Most frequent grade: " + ArrayUtils.getMostFrequent(grades));
        System.out.println("Grades above the average: " + ArrayUtils.countGreaterThanAverage(grades));

        input.nextLine();
        String[] words = new String[10];
        System.out.println("\\nEnter 10 names or words:");
        for (int i = 0; i < words.length; i++) {
            System.out.print("Text " + (i + 1) + ": ");
            words[i] = input.nextLine();
        }
        System.out.println("\\nText entered:");
        ArrayUtils.displayArray(words);
        System.out.println("Alphabetically first: " + ArrayUtils.findMin(words));
        System.out.println("Alphabetically last: " + ArrayUtils.findMax(words));
    }
}
