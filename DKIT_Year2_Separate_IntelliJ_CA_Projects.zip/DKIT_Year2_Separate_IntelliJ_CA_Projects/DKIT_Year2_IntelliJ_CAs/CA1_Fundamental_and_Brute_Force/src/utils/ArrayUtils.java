package utils;

/**
 * Utility methods for basic array operations and brute-force algorithms.
 */
public class ArrayUtils {

    /** Displays each integer and its index. */
    public static void displayArray(int[] nums) {
        for (int i = 0; i < nums.length; i++) {
            System.out.println("Position " + i + ": " + nums[i]);
        }
    }

    /** Displays each String and its index. */
    public static void displayArray(String[] text) {
        for (int i = 0; i < text.length; i++) {
            System.out.println("Position " + i + ": " + text[i]);
        }
    }

    /**
     * Calculates the arithmetic average of an integer array.
     * @param nums the values to average
     * @return the average, or 0.0 if the array is empty
     */
    public static double calcAverage(int[] nums) {
        if (nums.length == 0) return 0.0;
        int total = 0;
        for (int num : nums) total += num;
        return (double) total / nums.length;
    }

    /**
     * Finds the largest integer without sorting the array.
     * @param nums the values to search
     * @return the largest value, or Integer.MIN_VALUE if empty
     */
    public static int findMax(int[] nums) {
        if (nums.length == 0) return Integer.MIN_VALUE;
        int max = nums[0];
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] > max) max = nums[i];
        }
        return max;
    }

    /**
     * Finds the alphabetically last String, ignoring case.
     * @param text the Strings to search
     * @return the last String alphabetically, or an empty String if empty
     */
    public static String findMax(String[] text) {
        if (text.length == 0) return "";
        String max = text[0];
        for (int i = 1; i < text.length; i++) {
            if (text[i].compareToIgnoreCase(max) > 0) max = text[i];
        }
        return max;
    }

    /**
     * Finds the smallest integer without sorting the array.
     * @param nums the values to search
     * @return the smallest value, or Integer.MAX_VALUE if empty
     */
    public static int findMin(int[] nums) {
        if (nums.length == 0) return Integer.MAX_VALUE;
        int min = nums[0];
        for (int i = 1; i < nums.length; i++) {
            if (nums[i] < min) min = nums[i];
        }
        return min;
    }

    /**
     * Finds the alphabetically first String, ignoring case.
     * @param text the Strings to search
     * @return the first String alphabetically, or an empty String if empty
     */
    public static String findMin(String[] text) {
        if (text.length == 0) return "";
        String min = text[0];
        for (int i = 1; i < text.length; i++) {
            if (text[i].compareToIgnoreCase(min) < 0) min = text[i];
        }
        return min;
    }

    /**
     * Counts how often a value appears.
     * @param nums the array to search
     * @param value the value being counted
     * @return the number of occurrences
     */
    public static int count(int[] nums, int value) {
        int total = 0;
        for (int num : nums) if (num == value) total++;
        return total;
    }

    /**
     * Finds the most frequent integer. If tied, returns the first tied value encountered.
     * @param nums the array to search
     * @return the most frequent value, or Integer.MIN_VALUE if empty
     */
    public static int getMostFrequent(int[] nums) {
        if (nums.length == 0) return Integer.MIN_VALUE;
        int mostFrequent = nums[0];
        int highestCount = count(nums, mostFrequent);
        for (int i = 1; i < nums.length; i++) {
            int currentCount = count(nums, nums[i]);
            if (currentCount > highestCount) {
                highestCount = currentCount;
                mostFrequent = nums[i];
            }
        }
        return mostFrequent;
    }

    /**
     * Counts values greater than a supplied value.
     * @param nums the array to examine
     * @param value the comparison value
     * @return the number of values greater than value
     */
    public static int countGreater(int[] nums, int value) {
        int total = 0;
        for (int num : nums) if (num > value) total++;
        return total;
    }

    /**
     * Counts values greater than the array's average.
     * @param nums the array to examine
     * @return the number above the average
     */
    public static int countGreaterThanAverage(int[] nums) {
        return countGreater(nums, (int) calcAverage(nums));
    }
}
